import React from "react";

export default function Features() {
  const features = [
    {
      title: "Multimodal Understanding",
      desc: "VIDA processes both text and images to provide context-rich answers.",
    },
    {
      title: "Smart Conversations",
      desc: "Powered by advanced AI models for meaningful and human-like replies.",
    },
    {
      title: "Instant Insights",
      desc: "Ask questions, analyze visuals, and get real-time feedback instantly.",
    },
  ];

  return (
    <section className="features">
      <h2>✨ Why Choose VIDA?</h2>
      <div className="feature-grid">
        {features.map((f, i) => (
          <div key={i} className="feature-card">
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
