// frontend/src/ChatBot.jsx
import React, { useState, useRef, useEffect } from "react";


export default function ChatBot() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]); // simple list of {sender, text}
  const [loading, setLoading] = useState(false);
  const [autoPlay, setAutoPlay] = useState(false);
  const endRef = useRef(null);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userText = input.trim();
    setMessages((prev) => [...prev, { sender: "user", text: userText }]);
    setInput("");
    setLoading(true);

    // Temporary typing placeholders
    setMessages((prev) => [
      ...prev,
      { sender: "chatgpt", text: "ChatGPT is typing..." },
      { sender: "gemini", text: "Gemini is typing..." },
      { sender: "deepseek", text: "DeepSeek is typing..." },
      { sender: "consensus", text: "Generating consensus..." },
    ]);

    try {
      const resp = await fetch("http://localhost:5000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: userText }),
      });

      const data = await resp.json();

      // Remove placeholder messages
      setMessages((prev) =>
        prev.filter(
          (m) =>
            m.text !== "ChatGPT is typing..." &&
            m.text !== "Gemini is typing..." &&
            m.text !== "DeepSeek is typing..." &&
            m.text !== "Generating consensus..."
        )
      );

      // Append real replies
      setMessages((prev) => [
        ...prev,
        { sender: "chatgpt", text: data.chatgpt },
        { sender: "gemini", text: data.gemini },
        { sender: "deepseek", text: data.deepseek },
        { sender: "consensus", text: data.consensus },
      ]);

      // Optionally auto-play consensus
      if (autoPlay && data.consensus) {
        playConsensus(data.consensus);
      }
    } catch (err) {
      console.error("Fetch error:", err);
      setMessages((prev) => [...prev, { sender: "error", text: "Failed to fetch AI responses" }]);
    } finally {
      setLoading(false);
    }
  };

  const playConsensus = async (text) => {
    try {
      const res = await fetch("http://localhost:5000/speak", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) {
        console.error("TTS error", res.status);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();
    } catch (err) {
      console.error("Play consensus error:", err);
    }
  };

  return (
    <div style={{ maxWidth: 900, margin: "24px auto", padding: 12 }}>
      <div style={{
        background: "#0f172a", color: "white", padding: 20, borderRadius: 12, boxShadow: "0 6px 24px rgba(2,6,23,0.6)"
      }}>
        <h2 style={{ margin: 0 }}>VIDA — Multi-AI Chat</h2>
        <p style={{ marginTop: 6, color: "#cbd5e1" }}>Chat, compare, and listen to the consensus answer.</p>

        <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 12 }}>
          <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input type="checkbox" checked={autoPlay} onChange={(e) => setAutoPlay(e.target.checked)} />
            Auto-play consensus
          </label>
        </div>

        <div style={{ marginTop: 16, minHeight: 320, maxHeight: 480, overflowY: "auto", padding: 8, background: "#021028", borderRadius: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              display: "flex", marginBottom: 8, justifyContent: m.sender === "user" ? "flex-end" : "flex-start"
            }}>
              <div style={{
                maxWidth: "78%", padding: 12, borderRadius: 12,
                background: m.sender === "user" ? "#0ea5a4" :
                            m.sender === "chatgpt" ? "#065f46" :
                            m.sender === "gemini" ? "#6d28d9" :
                            m.sender === "deepseek" ? "#f59e0b" :
                            m.sender === "consensus" ? "#0b63c6" :
                            m.sender === "error" ? "#dc2626" : "#374151",
                color: m.sender === "deepseek" ? "black" : "white",
              }}>
                <strong style={{ display: "block", marginBottom: 6, fontSize: 12, opacity: 0.95 }}>
                  {m.sender === "user" ? "You" : m.sender.charAt(0).toUpperCase() + m.sender.slice(1)}
                </strong>
                <div style={{ whiteSpace: "pre-wrap" }}>{m.text}</div>

                {m.sender === "consensus" && (
                  <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                    <button onClick={() => playConsensus(m.text)} style={{ padding: "6px 10px", borderRadius: 8, cursor: "pointer" }}>
                      ▶ Play consensus
                    </button>
                    <button onClick={() => navigator.clipboard?.writeText(m.text)} style={{ padding: "6px 10px", borderRadius: 8, cursor: "pointer" }}>
                      📋 Copy
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          <div ref={endRef} />
        </div>

        <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
          <input
            type="text"
            placeholder="Type your message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            style={{ flex: 1, padding: 10, borderRadius: 8, border: "1px solid #0ea5a4", outline: "none" }}
          />
          <button onClick={sendMessage} disabled={loading} style={{
            padding: "10px 16px", borderRadius: 8, background: "#06b6d4", border: "none", cursor: "pointer"
          }}>
            {loading ? "..." : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
}
