import React from "react";

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Meet <span className="highlight">VIDA</span></h1>
        <p>
          Your AI-powered assistant that understands both text and images.
          Communicate naturally, get instant insights, and simplify your day.
        </p>
        <button
          className="hero-btn"
          onClick={() =>
            document.getElementById("chat-section").scrollIntoView({ behavior: "smooth" })
          }
        >
          Try VIDA Now
        </button>
      </div>
      <div className="hero-img">
        <img
          src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png"
          alt="AI Chatbot"
        />
      </div>
    </section>
  );
}
