// backend/index.js
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
import { GoogleGenerativeAI } from "@google/generative-ai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Init APIs
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const ELEVEN_API_KEY = process.env.ELEVEN_API_KEY;
const ELEVEN_VOICE_ID = process.env.ELEVEN_VOICE_ID || "EXAVITQu4vr4xnSDxMaL"; // fallback

// Utility: safe Gemini call (returns string or placeholder)
async function callGemini(text) {
  try {
    const geminiModel = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    console.log("Gemini model:", geminiModel);
    // generateContent expects an object with prompt or instructions
    const geminiResult = await geminiModel.generateContent({ prompt: text });
    // const gemini =
    //   geminiResult?.candidates?.[0]?.content?.[0]?.text ??
    //   "Gemini returned no content.";
    // return gemini;
    console.log("Gemini result:", geminiResult);
    return "Gemini returned no content."
  } catch (err) {
    console.log("Gemini text:", text);
    console.error("Gemini error:", err?.message ?? err);
    return "Gemini placeholder (error or no access).";
  }
}

// Utility: safe ChatGPT call
async function callChatGPT(text) {
  try {
    const gptRes = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: text }],
    });
    const chatgpt = gptRes.choices?.[0]?.message?.content ?? "No ChatGPT reply.";
    return chatgpt.trim();
  } catch (err) {
    console.error("OpenAI ChatGPT error:", err?.message ?? err);
    return "ChatGPT placeholder (error).";
  }
}

// Endpoint: POST /chat
// Accepts { text } and returns { chatgpt, gemini, deepseek, consensus }
app.post("/chat", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "No text provided" });

    // Call ChatGPT & Gemini in parallel
    const [chatgpt, gemini] = await Promise.all([callChatGPT(text), callGemini(text)]);

    // DeepSeek placeholder — update later when you have a real API
    const deepseek = "DeepSeek placeholder (not connected)";

    // Create consensus using ChatGPT (compare/summarize)
    let consensus = "Consensus placeholder (failed to generate).";
    try {
      const systemPrompt = `
You are a synthesis assistant. You will be given three model responses to the same user query (ChatGPT, Gemini, DeepSeek).
Your task: compare them, remove contradictions, and produce a short concise "consensus" answer (2-4 sentences). If they disagree, provide the most likely correct points and optionally say if there is uncertainty (one short sentence).
Return only the consensus text (no extra commentary).
`;
      const userPrompt = `User query:
${text}

ChatGPT response:
${chatgpt}

Gemini response:
${gemini}

DeepSeek response:
${deepseek}

Please produce a concise consensus answer.`;
      const consensusRes = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.2,
        max_tokens: 200,
      });
      consensus =
        consensusRes.choices?.[0]?.message?.content?.trim() ??
        "Consensus unavailable.";
    } catch (err) {
      console.error("Consensus generation error:", err?.message ?? err);
      consensus = "Consensus placeholder (error generating consensus).";
    }

    return res.json({ chatgpt, gemini, deepseek, consensus });
  } catch (err) {
    console.error("POST /chat error:", err?.message ?? err);
    return res.status(500).json({ error: "Server error" });
  }
});

// Endpoint: POST /speak
// Accepts { text, voice_id? } -> returns audio/mpeg bytes
app.post("/speak", async (req, res) => {
  try {
    const { text, voice_id } = req.body;
    if (!text) return res.status(400).json({ error: "No text provided" });

    const vid = voice_id || ELEVEN_VOICE_ID;
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(vid)}`;

    // Prepare ElevenLabs request body (streaming not mandatory)
    const elevenBody = {
      text,
      voice_settings: { stability: 0.6, similarity_boost: 0.75 },
    };

    const elevenResp = await fetch(url, {
      method: "POST",
      headers: {
        "xi-api-key": ELEVEN_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(elevenBody),
    });

    if (!elevenResp.ok) {
      const errText = await elevenResp.text();
      console.error("ElevenLabs API error:", elevenResp.status, errText);
      return res.status(502).json({ error: "ElevenLabs TTS error" });
    }

    const arrayBuffer = await elevenResp.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Return audio bytes as an MP3 (ElevenLabs returns audio/mpeg)
    res.setHeader("Content-Type", "audio/mpeg");
    res.send(buffer);
  } catch (err) {
    console.error("POST /speak error:", err?.message ?? err);
    res.status(500).json({ error: "Failed to synthesize speech" });
  }
});

// Simple health check
app.get("/", (req, res) => res.send("Backend up and running ✅"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Backend listening on http://localhost:${PORT}`));
